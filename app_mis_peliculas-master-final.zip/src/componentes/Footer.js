
import React from 'react'
export default ()=>(
	<div className="row bg-dark mt-5">
		<div className="col text-center my-auto">
			<div className="text-white">Trabajo HCI Avanzado</div>
			<div className="text-white">Edwin Narváez, Christian Moreira</div>
		</div>
	</div>
	)