
import React from 'react'
import Logo from '../img/logo.png'



export default ()=>(
	<div>
		<img src={Logo} alt="logo moviedb" width="200" height="75"/>
	</div>
	)