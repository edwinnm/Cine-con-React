import styled from 'styled-components'

const TituloSeccion =styled.h1` 
	background:rgba(120,144,15,1);
	color:white;
	margin:0;
`

export default TituloSeccion