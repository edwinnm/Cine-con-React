import React from 'react'
import {Form, Button, Col} from 'react-bootstrap'
import Seats from './Seats'

export default ()=>{
	const FECHAS = ["12-06-2020","13-06-2020","14-06-2020","15-06-2020","16-06-2020"]
	const FUNCIONES = ["11:00","15:00","17:00","19:00","21:00"]
	return (
		<div>
			<Form className="text-white">
				<Form.Row>
					<Form.Group as={Col} controlId="formGridEmail">
					<Form.Label> Fecha: </Form.Label>
						<Form.Control as="select" defaultValue="Escoja...">
						<option>Escoja...</option>
						{FECHAS.map(fecha => <option>{fecha}</option>)}
						</Form.Control>
					</Form.Group>
			
				<Form.Group as={Col} controlId="formGridEmail">
				<Form.Label>Sala</Form.Label>
					<Form.Control as="select" defaultValue="Escoja...">
					<option>Escoja...</option>
					<option>1</option>
					<option>2</option>
					<option>3</option>
					</Form.Control>
				</Form.Group>
				</Form.Row>
			
		
				<Form.Row>
				<Form.Group as={Col} controlId="formGridEmail">
				<Form.Label>Función: </Form.Label>
					<Form.Control as="select" defaultValue="Escoja...">
					<option>Escoja...</option>
					{FUNCIONES.map(funcion => <option> {funcion}</option>)}
					</Form.Control>
				</Form.Group>
			
				<Form.Group as={Col} controlId="formGridState">
					<Form.Label>Asientos: </Form.Label>
					<Form.Control as="input" type="number" placeholder="Numero de asientos" />
				</Form.Group>
				</Form.Row>
				
			
				<Button variant="primary" type="submit">
				Comprar
				</Button>
			</Form>
			<Seats/>
		</div>
	
	  )
}